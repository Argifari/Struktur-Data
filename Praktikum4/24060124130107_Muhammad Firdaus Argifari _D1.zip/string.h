/* Program   : string.h */
/* Deskripsi : file HEADER string */
/* Tanggal   : 21 September 2025*/
/***********************************/
#ifndef STRING_H
#define STRING_H

typedef struct {
    char value[100];
} string;

#endif