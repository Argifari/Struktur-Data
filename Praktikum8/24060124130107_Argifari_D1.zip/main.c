/* File : main.c */
/* Deskripsi : main driver ADT list berkait SIRKULAR dengan representasi fisik pointer */
/* NIM & Nama : 24060124130107 Muhammad Firdaus Argifari*/
/* Tanggal : 12 November 2025*/

// header
#include <stdio.h>
#include "list2.c"

// Program main 

int main () {
    // Kamus
    address P,A,B;
    infotype V;
    List2 Senarai;

    // Algoritma
    printf("\n\n=== Program Dimulai =====================================\n");
    printf("\n\n=== Testing Alokasi =====================================\n");
    A = Alokasi('G');
    printf("info(A)=%c\t", info(A) );
    B = Alokasi('N');
    next(B) = A;
    printf("info(B)=%c\n", B->info );
    
    printf("\n\n=== Testing Dealokasi ===================================\n");
    Dealokasi(&B);
    if (B == NIL) {
        printf("Dealokasi address berhasil\n");
    }else {
        printf("Dealokasi address tidak berhasil\n");

    }

    printf("\n\n=== Testing CreateList ==================================\n");
    CreateList(&Senarai);
    printf("Isi Senarai :");
    PrintList(Senarai);
    printf("\nHitung elemen Senarai : %d", NbElm(Senarai));

    printf("\n\n=== Testing InsertVFirst ================================\n");
    InsertVFirst(&Senarai, 'N');
    InsertVFirst(&Senarai, 'a');
    InsertVFirst(&Senarai, 's');
    printf("Isi Senarai :");
    PrintList(Senarai);
    printf("\nHitung elemen Senarai : %d", NbElm(Senarai));
    
    printf("\n\n=== Testing EmptyList ===================================\n");
    if (IsEmptyList(Senarai)) {
        printf("Senarai kosong\n");
    }else {
        printf("Senarai tidak kosong\n");
    }
    printf("\n\n=== Testing IsOneElm ====================================\n");
    if (IsOneElm(Senarai)) {
        printf("Senarai satu elemen\n");
    }else {
        printf("Senarai tidak satu elemen\n");
    }
    
    printf("\n\n=== Testing InsertVLast =================================\n");
    InsertVLast(&Senarai, 's');
    InsertVLast(&Senarai, 'z');
    InsertVLast(&Senarai, 'o');
    printf("\nIsi Senarai :");
    PrintList(Senarai);
    printf("\nHitung elemen Senarai : %d", NbElm(Senarai));
    
    printf("\n\n=== Test DeleteVFirst ===================================\n");
  
    DeleteVFirst(&Senarai, &V);
  
    printf("\nIsi Senarai :");
    PrintList(Senarai);
    printf("\nHitung elemen Senarai : %d", NbElm(Senarai));
    printf("\nelemen Senarai yang dihapus : %c\n", V);
    
    DeleteVLast(&Senarai, &V);
    
    printf("\n\n=== Test DeleteVLast ====================================\n");
    printf("\nIsi Senarai :");
    PrintList(Senarai);
    printf("\nHitung elemen Senarai : %d", NbElm(Senarai));
    printf("\nelemen Senarai yang dihapus : %c\n", V);
    
    printf("\n\n=== Test DeleteX ========================================\n");
    
    DeleteX(&Senarai, 'z');
    printf("\nIsi Senarai :");
    PrintList(Senarai);
    printf("\nHitung elemen Senarai : %d", NbElm(Senarai));
    
    printf("\n\n=== Test SearchX ========================================\n");
    
    SearchX(Senarai, 'N',&B);
    printf("\nIsi Senarai :");
    PrintList(Senarai);
    printf("\nHitung elemen Senarai : %d\n", NbElm(Senarai));
    if (B == NIL) {
        printf("N tidak ditemukan\n");
    }else {
        printf("N ditemukan\n");
    }
    
    printf("\n\n=== Test UpdateX ========================================\n");
    
    UpdateX(&Senarai, 'a', 'j');
    printf("\nIsi Senarai :");
    PrintList(Senarai);
    printf("\nHitung elemen Senarai : %d\n", NbElm(Senarai));
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    printf("\n\n=== Program Selesai ======================================\n");
    return 0;
}
