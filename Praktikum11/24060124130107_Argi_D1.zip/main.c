/* File : main.c */
/* Deskripsi : main driver ADT bintree berkait dengan representasi fisik pointer */
/* pohon2 melengkapi operator ADT bintree yang ada dalam pohon1 */
/* NIM & Nama : 24060124130107 & Muhammad Firdaus Argifari*/
/* Tanggal : 3 December 2025*/

#include "pohon2.h"

int main () {
    // Kamus 
    bintree B;
    infotype Y;
    infotype X;

    // Algoritma
    printf("\n\n== Program dimulai =========================\n");
    printf("\n\n== Test Tree ===============================\n");
    B = Tree('T',
        Tree('I',
            Tree('N',NIL,NIL),
            Tree('F',
                Tree('O',NIL,NIL),
                NIL)),
        Tree('R',
                    Tree('M',
                        Tree('A',NIL,NIL),
                        Tree('T',NIL,NIL)),
                    Tree('I',
                            NIL,
                            Tree('K',
                                NIL,
                                Tree('A',NIL,NIL))))
    );
    
    printf("\n\n== Test PrintTreeInden =====================\n");
    printf("Hasil print seperti explorer : \n");
    PrintTreeInden(B,1);
    
    printf("\n\n== Test UpdateAllX =========================\n");
    X = 'I';
    Y = 'H';
    printf("Memperbarui semua yang bernilai %c dengan %c : \n", X,Y);
    UpdateAllX(&B,X,Y);
    printf("Hasil print seperti explorer : \n");
    PrintTreeInden(B,1);
    
    printf("\n\n== Test AddDaunTerkiri =====================\n");
    X = 'P';
    printf("Menambahkan elemen %c pada daun terkiri :\n",X);
    AddDaunTerkiri(&B,X);
    printf("Hasil print seperti explorer : \n");
    PrintTreeInden(B,1);
    
    printf("\n\n== Test AddDaun ============================\n");
    X = 'A';
    Y = 'C';
    printf("Menambahkan elemen %c pada daun dengan elemen %c :\n",Y,X);
    AddDaun(&B,X,Y,true);
    printf("Hasil print seperti explorer : \n");
    PrintTreeInden(B,1);
    

    return 0;
}