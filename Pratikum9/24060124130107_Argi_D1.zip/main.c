/* File : list3.c */
/* Deskripsi : Main body ADT list berkait dengan representasi fisik pointer */
/* NIM & Nama : 24060124130107 Muhammad Firdaus Argifari*/
/* Tanggal : 19 November 2025*/

// header file
#include <stdio.h>
#include "list3.c"

// main program

int main () {
    // Kamus
    address A;
    address B;
    List3 Senarai;
    infotype V;

    // Algoritma

    printf("\n\n== Test Alokasi =============================\n\n");
    A = Alokasi('a');
    B = Alokasi('j');
    printf("Isi address B : %c\n", info(B));
    
    printf("\n\n== Test Dealokasi ===========================\n\n");
    Dealokasi(&B);
    if (B == NIL) {
        printf("Dealokasi berhasil\n");
    }else {
        printf("Dealokasi tidak berhasil\n");
    }
    printf("\n\n== Test CreateList ==========================\n\n");
    CreateList(&Senarai);
    
    if (First(Senarai) == NIL) {
        printf("CreateList berhasil\n");
    }else {
        printf("CreateList tidak berhasil\n");
    }
    
    printf("\n\n== Test IsEmptyList =========================\n\n");
    
    if (IsEmptyList(Senarai)) {
        printf("List kosong\n");
    }else {
        printf("List tidak kosong\n");
    }
    printf("\n\n== Test NbElm ===============================\n\n");
    
    printf("Jumlah elemen list sekarang : %d\n", NbElm(Senarai));
    
    printf("\n\n== Test InsertVFirst ========================\n\n");
    
    printf("Insert Karakter a  : \n");
    InsertVFirst(&Senarai,'a');
    PrintList(Senarai);
    printf("Jumlah elemen list sekarang : %d\n", NbElm(Senarai));
    
    printf("\n\n== Test InsertVLast =========================\n\n");
    printf("Insert Karakter b di akhir : \n");
    InsertVLast(&Senarai,'b');
    PrintList(Senarai);
    printf("Jumlah elemen list sekarang : %d\n", NbElm(Senarai));
    
    printf("\n\n== Test DeleteVFirst ========================\n\n");
    DeleteVFirst(&Senarai,&V);
    PrintList(Senarai);
    printf("Jumlah elemen list sekarang : %d\n", NbElm(Senarai));
    printf("Elemen list yang dihapus : %c\n", V);
    
    printf("\n\n== Test DeleteVLast =========================\n\n");
    InsertVLast(&Senarai,'g');
    InsertVLast(&Senarai,'c');
    printf("Kondisi sebelum DeleteVLast : \n");
    PrintList(Senarai);
    DeleteVLast(&Senarai,&V);
    printf("\nKondisi setelah DeleteVLast : \n");
    PrintList(Senarai);
    printf("Jumlah elemen list sekarang : %d\n", NbElm(Senarai));
    printf("Elemen list yang dihapus : %c\n", V);
    
    printf("\n\n== Test DeleteX =============================\n\n");
    InsertVLast(&Senarai,'h');
    printf("Kondisi sebelum DeleteVLast : \n");
    PrintList(Senarai);
    DeleteX(&Senarai,'g');
    printf("\nKondisi setelah DeleteX X = g : \n");
    PrintList(Senarai);
    printf("Jumlah elemen list sekarang : %d\n", NbElm(Senarai));
    
    printf("\n\n== Test SearchX =============================\n\n");
    A = NIL;
    
    InsertVLast(&Senarai,'h');
    InsertVLast(&Senarai,'f');
    InsertVLast(&Senarai,'z');
    PrintList(Senarai);
    printf("Jumlah elemen list sekarang : %d\n", NbElm(Senarai));
    
    SearchX(Senarai,'z',&A);
    if (A == NIL) {
        printf("z tidak ditemukan di list\n");
    }else {
        printf("z ditemukan di list\n");
    }

    
    
    
    printf("\n\n== Program Selesai ==========================\n\n");

    return 0;
}
