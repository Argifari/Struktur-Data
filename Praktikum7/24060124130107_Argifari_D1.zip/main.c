/* File : main.c */
/* Deskripsi : aplikasi driver ADT list berkait, representasi fisik pointer */
/* NIM & Nama : 24060124130107 Muhammad Firdaus Argifari*/
/* Tanggal : 5 November 2025 */
#include <stdio.h>
#include <stdlib.h>
#include "list1.c"
int main()
{ //kamus
  address A; 
  address B;
  address P;
  infotype V;
  List1 Senarai;
  //algoritma
  
  //aplikasi tipe address
  
  // A = (address) malloc ( sizeof (Elm) ); // Alokasi('G')
  // A->info = 'G';   A->next = NIL;
  A = Alokasi('G');
  printf("info(A)=%c\t", info(A) );
  // B = (address) malloc ( sizeof (Elm) ); // Alokasi('N')
  // B->info = 'N';   B->next = A;
  B = Alokasi('N');
  next(B) = A;

  printf("info(B)=%c\n", B->info );
  
  //aplikasi tipe List1
  CreateList(&Senarai);
  InsertVFirst(&Senarai, 'N');
  printf("Isi Senarai :");
  PrintList(Senarai);
  printf("\nHitung elemen Senarai : %d", NbElm(Senarai));
  
  InsertVLast(&Senarai, 'G');
  InsertVLast(&Senarai, 'a');
  InsertVLast(&Senarai, 'f');
  printf("\nIsi Senarai :");
  PrintList(Senarai);
  printf("\nHitung elemen Senarai : %d", NbElm(Senarai));

  printf("\n\n=============================================== DeleteVFirst =====================================\n");

  DeleteVFirst(&Senarai, &V);

  printf("\nIsi Senarai :");
  PrintList(Senarai);
  printf("\nHitung elemen Senarai : %d", NbElm(Senarai));



  return 0;
}
