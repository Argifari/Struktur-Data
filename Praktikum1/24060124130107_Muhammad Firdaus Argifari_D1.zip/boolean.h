/*File    	: boolean.h*/
/*Deskripsi : Header fungsi boolean */
/*Dibuat    : Aris Puji Widodo    (23501008)*/
/*Tanggal   : Thu 20 Sep 2001 09:33:24 AM JAVT*/

/* Kamus */
#ifndef boolean_H
#define boolean_H
#define true 1
#define false 0
#define boolean unsigned char
#endif
